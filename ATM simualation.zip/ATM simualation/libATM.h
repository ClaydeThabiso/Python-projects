#ifndef LIBATM_H_INCLUDED
#define LIBATM_H_INCLUDED
#include <iostream>
#include <cstdlib>
using namespace std;
namespace AtmSpace
{

    void Simulation(int& intTransaction,char chOption);
    void print();
    void logTransaction(const string& transaction);
}


#endif // LIBATM_H_INCLUDED
