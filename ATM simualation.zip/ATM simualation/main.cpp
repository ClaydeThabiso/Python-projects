#include <iostream>
#include <cassert>
#include "libATM.h"

using namespace AtmSpace;
using namespace std;

int main()
{
    int intTransaction = 0;
    bool blnContinue = true;
    char chOption = '\n';

    cout << "WELCOME TO THABISO BANK ENTERPRISE" << endl;
    do {
        print();
        cin >> chOption;
        chOption = tolower(chOption);

        switch (chOption)
        {
        case 'd':
        case 'w':
        case 'v':
            Simulation(intTransaction, chOption);
            break;
        case 'q':
            cout << "Thank you for using THABISO ENTERPRISE BANK" << endl;
            blnContinue = false;
            break;
        default:
            cerr << "Invalid option" << endl;
            break;
        }
    } while (blnContinue);

    return 0;
}
