#include "libATM.h"
#include <fstream> // Include fstream for file operations

namespace AtmSpace
{
    void logTransaction(const string& transaction) {
        ofstream outFile("transactions.log", ios::app);
        if (outFile.is_open()) {
            outFile << transaction <<endl;
            outFile.close();
        } else {
            cerr << "Unable to open transactions log file" <<endl;
        }
    }

    void Simulation(int& intTransaction, char chOption)
    {
        switch (chOption)
        {
        case 'd':
        {
            int intDeposit;
            cout << "Enter the deposit: ";
            cin >> intDeposit;
            intTransaction += intDeposit;
            cout << "Available balance: " << intTransaction << endl;

            string transaction = "Deposit: " + to_string(intDeposit) + ", New Balance: " + to_string(intTransaction);
            logTransaction(transaction);
            break;
        }
        case 'w':
        {
            int intWithdraw;
            cout << "Enter the withdrawal: ";
            cin >> intWithdraw;
            if (intWithdraw <= intTransaction)
            {
                intTransaction -= intWithdraw;
                cout << "Available balance: " << intTransaction << endl;

                string transaction = "Withdraw: " + to_string(intWithdraw) + ", New Balance: " + to_string(intTransaction);
                logTransaction(transaction);
            }
            else
            {
                cout << "Not enough funds to withdraw" << endl;
            }
            break;
        }
        case 'v':
            cout << "Current balance: " << intTransaction << endl;
            break;
        case 'q':
            break;
        default:
            cerr << "Invalid option" << endl;
            break;
        }
    }

    void print()
    {
        cout <<endl
                  << "What would you like to do? Choose below" <<endl
                  << "D - Deposit" <<endl
                  << "W - Withdraw" <<endl
                  << "V - View balance" << endl
                  << "Q - Quit Bank" <<endl;
    }
}
