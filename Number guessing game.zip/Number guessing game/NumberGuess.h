#ifndef NUMBERGUESS_H_INCLUDED
#define NUMBERGUESS_H_INCLUDED
#include <iostream>
#include <cmath>
#include <ctime>

using namespace std;

int GenNum(int intLB ,int intHB);
void simulationGuessing();

#endif // NUMBERGUESS_H_INCLUDED
