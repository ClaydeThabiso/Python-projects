#include "NumberGuess.h"

int GenNum(int intLB, int intHB)
{
    int rangeNum= intHB- intLB+1;
    return rand()% rangeNum+intLB;
}
void simulationGuessing()
{
    int intNum;
    int randomNum=GenNum(0,50);
    int intCount=5;
   do
    {
        cout<<"You have "<<intCount<<" tries left"<<endl;
        cout<<"Enter your guess number : ";
        cin>>intNum;
        intCount-=1;
        if (intNum > randomNum)
        {
            cout<<"Too High "<<endl;
        }
        else if(intNum<randomNum)
        {
            cout<<"Too Low"<<endl;
        }
        else
        {
            cout<<"Correct!!"<<endl;
        }
        if(intCount==0 && intNum!=randomNum)
        {
            cout<<"Hard luck ,out of tries"<<endl;
            cout<<"The correct number was : "<<randomNum<<endl;
        }
        cout<<endl;
    }while(intCount!=0 && intNum!=randomNum);
}
