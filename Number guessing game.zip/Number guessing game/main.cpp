#include <iostream>
#include "NumberGuess.h"
using namespace std;

int main()
{
    srand(time(0));
    cout << "Number Guess Game" << endl;
    cout<<"Guess a number between 1-50"<<endl;
    cout<<endl;
    simulationGuessing();
    cout<<endl;
    char chOPtion;
    do
    {
        cout<<"Try again? Y / N : ";
        cin>>chOPtion;
        switch(chOPtion)
        {
        case'y':
            cout <<"Number Guess Game"<<endl;
            cout<<"Guess a number between 1-50"<<endl;
            simulationGuessing();
            break;
        case 'n':
            cout<<"Thanks for playing"<<endl;
            break;
        }
    }while(chOPtion!='n');

    return 0;
}
